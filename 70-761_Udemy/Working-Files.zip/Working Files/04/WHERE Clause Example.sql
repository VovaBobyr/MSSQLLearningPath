
-- WHERE clause example

USE AdventureWorks2012;

SELECT 
  *
FROM 
  Person.Person
WHERE  
	LastName = 'Adams' AND FirstName = 'Alex'


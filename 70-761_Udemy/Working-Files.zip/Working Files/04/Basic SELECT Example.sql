-- Basic SELECT Statement
-- The USE statement sets the context, or database,
-- that the query will be executed against
USE AdventureWorks2012;

SELECT 
  LastName, FirstName
FROM 
  Person.Person